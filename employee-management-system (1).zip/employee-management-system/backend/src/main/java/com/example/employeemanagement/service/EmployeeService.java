package com.example.employeemanagement.service;

import com.example.employeemanagement.model.Employee;
import com.example.employeemanagement.repository.EmployeeRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class EmployeeService {

    private final EmployeeRepository repository;

    public EmployeeService(EmployeeRepository repository) {
        this.repository = repository;
    }

    public List<Employee> getAllEmployees(String search) {
        if (search == null || search.isBlank()) {
            return repository.findAll();
        }
        String term = search.trim();
        return repository
                .findByNameContainingIgnoreCaseOrEmailContainingIgnoreCaseOrDepartmentContainingIgnoreCase(
                        term, term, term);
    }

    public Employee getEmployeeById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Employee not found with id " + id));
    }

    public Employee createEmployee(Employee employee) {
        if (repository.existsByEmailIgnoreCase(employee.getEmail().trim())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "An employee with this email already exists");
        }
        employee.setId(null);
        employee.setName(employee.getName().trim());
        employee.setEmail(employee.getEmail().trim());
        employee.setDepartment(employee.getDepartment().trim());
        try {
            return repository.save(employee);
        } catch (DataIntegrityViolationException ex) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "An employee with this email already exists");
        }
    }

    public Employee updateEmployee(Long id, Employee input) {
        Employee existing = getEmployeeById(id);
        String email = input.getEmail().trim();

        if (repository.existsByEmailIgnoreCaseAndIdNot(email, id)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Another employee already uses this email");
        }

        existing.setName(input.getName().trim());
        existing.setEmail(email);
        existing.setDepartment(input.getDepartment().trim());
        existing.setSalary(input.getSalary());
        try {
            return repository.save(existing);
        } catch (DataIntegrityViolationException ex) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "An employee with this email already exists");
        }
    }

    public void deleteEmployee(Long id) {
        Employee employee = getEmployeeById(id);
        repository.delete(employee);
    }
}
