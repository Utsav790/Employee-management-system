const BASE_URL = '/api/employees';

async function request(url, options = {}) {
  const response = await fetch(url, {
    headers: {
      'Content-Type': 'application/json',
      ...(options.headers || {})
    },
    ...options
  });

  if (!response.ok) {
    let message = `Request failed (${response.status})`;
    try {
      const body = await response.json();
      message = body.message || body.detail || body.error || message;
    } catch {
      // Keep the fallback message when the server response is not JSON.
    }
    throw new Error(message);
  }

  if (response.status === 204) return null;
  return response.json();
}

export const employeeApi = {
  list(search = '') {
    const query = search.trim()
      ? `?search=${encodeURIComponent(search.trim())}`
      : '';
    return request(`${BASE_URL}${query}`);
  },
  create(employee) {
    return request(BASE_URL, {
      method: 'POST',
      body: JSON.stringify(employee)
    });
  },
  update(id, employee) {
    return request(`${BASE_URL}/${id}`, {
      method: 'PUT',
      body: JSON.stringify(employee)
    });
  },
  remove(id) {
    return request(`${BASE_URL}/${id}`, { method: 'DELETE' });
  }
};
