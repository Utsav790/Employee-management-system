# Employee Management System

A beginner-friendly full-stack Employee Management System built with React + Vite, Java 17+, Spring Boot, Spring Data JPA, Bean Validation, and MySQL.

## Features
- Add, list, edit, and delete employees
- Search by name, email, or department
- Basic request validation and user-friendly API errors
- Responsive React UI
- MySQL persistence

## Requirements
- Java 17 or later
- Maven 3.9+ (or use your IDE's Maven support)
- Node.js 20.19+ or 22.12+ (for a current Vite release)
- MySQL 8+
- npm

## 1. Create the database
Start MySQL and run:

```sql
CREATE DATABASE employee_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

The application creates/updates the `employees` table using JPA. For a local learning project, `ddl-auto=update` is convenient. For production, use database migrations and managed secrets.

## 2. Configure the backend
Edit `backend/src/main/resources/application.properties` and set your MySQL username/password. Defaults are:
- URL: `jdbc:mysql://localhost:3306/employee_db`
- Username: `root`
- Password: `YOUR_PASSWORD`

Do not commit real credentials to a public repository.

## 3. Run Spring Boot
From a terminal:

```bash
cd backend
mvn spring-boot:run
```

Backend runs at `http://localhost:8080`.

Check the API:
- `GET http://localhost:8080/api/employees`
- `GET http://localhost:8080/api/employees/1`

## 4. Run React
Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the URL Vite prints, normally `http://localhost:5173`.

Vite proxies `/api` requests to Spring Boot on port 8080, so the frontend uses relative API paths.

## API endpoints

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/employees` | List employees |
| GET | `/api/employees/{id}` | Get one employee |
| POST | `/api/employees` | Create employee |
| PUT | `/api/employees/{id}` | Update employee |
| DELETE | `/api/employees/{id}` | Delete employee |

### Example POST body
```json
{
  "name": "Rahul Sharma",
  "email": "rahul@example.com",
  "department": "Engineering",
  "salary": 45000
}
```

## Troubleshooting
- **Cannot connect to MySQL:** confirm the MySQL service is running and the database exists.
- **Access denied:** check `spring.datasource.username` and `spring.datasource.password`.
- **Port 8080 is in use:** stop the other process or change `server.port` in `application.properties` and update the Vite proxy target.
- **Port 5173 is in use:** Vite usually offers another port.
- **`mvn` not found:** install Maven, or run from an IDE that has Maven support.
- **Java version error:** check `java -version`; use Java 17 or newer.
- **Frontend API errors:** start the backend first, then refresh the React page.

## Project structure
```text
employee-management-system/
├── backend/
│   ├── pom.xml
│   └── src/main/
│       ├── java/com/example/employeemanagement/
│       │   ├── EmployeeManagementApplication.java
│       │   ├── controller/EmployeeController.java
│       │   ├── exception/GlobalExceptionHandler.java
│       │   ├── model/Employee.java
│       │   ├── repository/EmployeeRepository.java
│       │   └── service/EmployeeService.java
│       └── resources/application.properties
└── frontend/
    ├── index.html
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── main.jsx
        ├── App.jsx
        ├── api.js
        └── styles.css
```
