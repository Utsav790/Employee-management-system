import { useCallback, useEffect, useMemo, useState } from 'react';
import { employeeApi } from './api.js';

const emptyForm = {
  name: '',
  email: '',
  department: '',
  salary: ''
};

function formatSalary(value) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2
  }).format(Number(value || 0));
}

function initials(name = '') {
  return name.trim().split(/\s+/).slice(0, 2).map((part) => part[0]?.toUpperCase()).join('');
}

export default function App() {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const loadEmployees = useCallback(async (term = search) => {
    setLoading(true);
    setError('');
    try {
      const data = await employeeApi.list(term);
      setEmployees(data);
    } catch (err) {
      setError(err.message || 'Could not load employees. Is the backend running?');
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => {
    loadEmployees('');
  }, []); // Load the initial employee list once.

  useEffect(() => {
    const timer = setTimeout(() => {
      loadEmployees(search);
    }, 250);
    return () => clearTimeout(timer);
  }, [search, loadEmployees]);

  const stats = useMemo(() => ({
    total: employees.length,
    departments: new Set(employees.map((employee) => employee.department)).size,
    payroll: employees.reduce((sum, employee) => sum + Number(employee.salary || 0), 0)
  }), [employees]);

  function startEdit(employee) {
    setEditingId(employee.id);
    setForm({
      name: employee.name,
      email: employee.email,
      department: employee.department,
      salary: String(employee.salary ?? '')
    });
    setError('');
    setNotice('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function resetForm() {
    setEditingId(null);
    setForm(emptyForm);
  }

  function handleChange(event) {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
  }

  async function handleSubmit(event) {
    event.preventDefault();
    setError('');
    setNotice('');

    const payload = {
      name: form.name.trim(),
      email: form.email.trim(),
      department: form.department.trim(),
      salary: Number(form.salary)
    };

    if (!payload.name || !payload.email || !payload.department || form.salary === '') {
      setError('Please complete all fields.');
      return;
    }
    if (!Number.isFinite(payload.salary) || payload.salary < 0) {
      setError('Salary must be a number greater than or equal to zero.');
      return;
    }

    setSaving(true);
    try {
      if (editingId !== null) {
        await employeeApi.update(editingId, payload);
        setNotice('Employee updated successfully.');
      } else {
        await employeeApi.create(payload);
        setNotice('Employee added successfully.');
      }
      resetForm();
      await loadEmployees(search);
    } catch (err) {
      setError(err.message || 'Could not save employee.');
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(employee) {
    const confirmed = window.confirm(`Delete ${employee.name}? This cannot be undone.`);
    if (!confirmed) return;

    setError('');
    setNotice('');
    try {
      await employeeApi.remove(employee.id);
      if (editingId === employee.id) resetForm();
      setNotice(`${employee.name} was deleted.`);
      await loadEmployees(search);
    } catch (err) {
      setError(err.message || 'Could not delete employee.');
    }
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <a className="brand" href="/" aria-label="Employee Hub home">
          <span className="brand-mark">EH</span>
          <span>Employee<span className="brand-light">Hub</span></span>
        </a>
        <span className="topbar-label"><span className="status-dot" /> Management portal</span>
      </header>

      <section className="page-heading">
        <div>
          <p className="eyebrow">PEOPLE OPERATIONS</p>
          <h1>Employee management</h1>
          <p className="subtitle">Manage your team, all in one place.</p>
        </div>
        <div className="heading-icon" aria-hidden="true">♙</div>
      </section>

      {error && <div className="alert alert-error" role="alert"><span>!</span>{error}<button onClick={() => setError('')} aria-label="Dismiss error">×</button></div>}
      {notice && <div className="alert alert-success" role="status"><span>✓</span>{notice}<button onClick={() => setNotice('')} aria-label="Dismiss message">×</button></div>}

      <section className="stats-grid" aria-label="Employee summary">
        <article className="stat-card">
          <div className="stat-icon blue">♙</div>
          <div><p>Total employees</p><strong>{stats.total}</strong><small>In current results</small></div>
        </article>
        <article className="stat-card">
          <div className="stat-icon purple">▦</div>
          <div><p>Departments</p><strong>{stats.departments}</strong><small>Represented in results</small></div>
        </article>
        <article className="stat-card">
          <div className="stat-icon green">₹</div>
          <div><p>Monthly payroll</p><strong className="payroll">{formatSalary(stats.payroll)}</strong><small>Sum of current results</small></div>
        </article>
      </section>

      <section className="content-grid">
        <aside className="panel form-panel">
          <div className="panel-heading">
            <div>
              <p className="eyebrow">{editingId !== null ? 'UPDATE RECORD' : 'NEW RECORD'}</p>
              <h2>{editingId !== null ? 'Edit employee' : 'Add employee'}</h2>
            </div>
            <span className="panel-symbol">{editingId !== null ? '✎' : '+'}</span>
          </div>
          <form onSubmit={handleSubmit}>
            <label htmlFor="name">Full name <span>*</span></label>
            <input id="name" name="name" value={form.name} onChange={handleChange} placeholder="e.g. Aditi Sharma" maxLength="100" required />
            <label htmlFor="email">Email address <span>*</span></label>
            <input id="email" name="email" type="email" value={form.email} onChange={handleChange} placeholder="aditi@company.com" maxLength="150" required />
            <label htmlFor="department">Department <span>*</span></label>
            <select id="department" name="department" value={form.department} onChange={handleChange} required>
              <option value="" disabled>Select department</option>
              <option>Engineering</option>
              <option>Human Resources</option>
              <option>Finance</option>
              <option>Marketing</option>
              <option>Sales</option>
              <option>Operations</option>
              <option>Design</option>
              <option>Customer Support</option>
              <option>Other</option>
            </select>
            <label htmlFor="salary">Monthly salary (₹) <span>*</span></label>
            <div className="salary-input"><span>₹</span><input id="salary" name="salary" type="number" min="0" step="0.01" value={form.salary} onChange={handleChange} placeholder="45000" required /></div>
            <div className="form-actions">
              <button className="button button-primary" type="submit" disabled={saving}>
                {saving ? 'Saving…' : editingId !== null ? 'Save changes' : '+ Add employee'}
              </button>
              {editingId !== null && <button className="button button-secondary" type="button" onClick={resetForm}>Cancel</button>}
            </div>
          </form>
          <p className="form-footnote"><span>*</span> Required fields</p>
        </aside>

        <section className="panel employees-panel">
          <div className="employee-panel-top">
            <div>
              <p className="eyebrow">YOUR ORGANIZATION</p>
              <h2>All employees <span className="count-badge">{employees.length}</span></h2>
            </div>
            <div className="search-box">
              <span aria-hidden="true">⌕</span>
              <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search employees…" aria-label="Search employees" />
              {search && <button onClick={() => setSearch('')} aria-label="Clear search">×</button>}
            </div>
          </div>

          {loading ? (
            <div className="empty-state"><div className="spinner" /><p>Loading employees…</p></div>
          ) : employees.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon">♙</div>
              <h3>{search ? 'No matching employees' : 'No employees yet'}</h3>
              <p>{search ? 'Try a different name, email, or department.' : 'Add your first employee using the form.'}</p>
            </div>
          ) : (
            <div className="table-wrap">
              <table>
                <thead><tr><th>EMPLOYEE</th><th>DEPARTMENT</th><th>MONTHLY SALARY</th><th className="actions-heading">ACTIONS</th></tr></thead>
                <tbody>
                  {employees.map((employee) => (
                    <tr key={employee.id}>
                      <td>
                        <div className="employee-cell">
                          <span className="avatar">{initials(employee.name)}</span>
                          <div className="employee-identity"><strong>{employee.name}</strong><span>{employee.email}</span></div>
                        </div>
                      </td>
                      <td><span className="department-pill">{employee.department}</span></td>
                      <td className="salary-cell">{formatSalary(employee.salary)}</td>
                      <td><div className="row-actions">
                        <button className="icon-button edit-button" onClick={() => startEdit(employee)} title={`Edit ${employee.name}`} aria-label={`Edit ${employee.name}`}>✎</button>
                        <button className="icon-button delete-button" onClick={() => handleDelete(employee)} title={`Delete ${employee.name}`} aria-label={`Delete ${employee.name}`}>⌫</button>
                      </div></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          <div className="table-footer"><span>Showing <strong>{employees.length}</strong> employee{employees.length === 1 ? '' : 's'}</span><span className="live-indicator"><span className="status-dot" /> Connected to database</span></div>
        </section>
      </section>

      <footer className="footer"><span>EmployeeHub</span><span>Simple tools for a stronger team.</span></footer>
    </main>
  );
}
